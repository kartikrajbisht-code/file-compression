# 📦 Instructions for Member 4 (RLE & Extensibility Specialist)

Hello **Member 4**! You are responsible for the PackBits Run-Length Encoding (RLE) algorithm and the extensible polymorphic factory for our team's File Compression System project.

---

## 📁 Your Assigned Files
- `include/ICompressor.hpp`: Abstract base interface defining `compress()` and `decompress()`.
- `include/RLE.hpp` & `src/RLE.cpp`: PackBits Run-Length Encoding compressor.
- `include/CompressorFactory.hpp` & `src/CompressorFactory.cpp`: Factory pattern mapping algorithm types to compressor instances.

---

## 🧪 How to Test Your Code
Double click `build_test.bat` (or run it in terminal):
```cmd
.\build_test.bat
```
It will compile and run `test_member4.cpp` to verify algorithm instantiation and RLE compression/decompression.

---

## 🚀 How to Commit to GitHub
When our Team Leader tells you to commit your work on GitHub:
1. Make sure you are in the project repository root.
2. Run `commit_my_role.bat` (or run the commands manually):
```bash
git checkout -b feature/member4-rle-factory
git add include/ICompressor.hpp include/RLE.hpp src/RLE.cpp include/CompressorFactory.hpp src/CompressorFactory.cpp docs/roles/MEMBER_4_RLE_FACTORY.md
git commit -m "feat(algo): implement PackBits RLE compressor, abstract interface, and factory"
git push -u origin feature/member4-rle-factory
```
3. Open a Pull Request to `main` on GitHub so the Leader can merge it!
