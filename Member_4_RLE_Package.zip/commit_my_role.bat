@echo off
echo ==============================================
echo   Member 4 Git Committer (RLE & Factory)
echo ==============================================
git checkout -b feature/member4-rle-factory
git add include/ICompressor.hpp include/RLE.hpp src/RLE.cpp include/CompressorFactory.hpp src/CompressorFactory.cpp docs/roles/MEMBER_4_RLE_FACTORY.md
git commit -m "feat(algo): implement PackBits RLE compressor, abstract interface, and factory"
echo.
echo Files committed to branch feature/member4-rle-factory!
echo When ready, push using: git push -u origin feature/member4-rle-factory
pause
