@echo off
echo Compiling Member 4 Unit Test...
g++ -std=c++14 -Iinclude src\RLE.cpp src\CompressorFactory.cpp src\Huffman.cpp src\HuffmanTree.cpp src\BitStream.cpp test_member4.cpp -o test_member4.exe
if %ERRORLEVEL% EQU 0 (
    echo Compilation successful! Running test...
    echo.
    test_member4.exe
) else (
    echo [ERROR] Compilation failed.
)
pause
